# utils.py
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, roc_auc_score, confusion_matrix
import matplotlib.pyplot as plt

def calc_metrics(y_true, y_pred, y_prob, num_classes):
    acc = accuracy_score(y_true, y_pred)
    prec, rec, f1, _ = precision_recall_fscore_support(y_true,y_pred,average="macro",zero_division=0)
    macro_auc = roc_auc_score(y_true, y_prob, multi_class="ovr",average="macro")
    return {
        "acc":acc,
        "macro_precision":prec,
        "macro_recall":rec,
        "macro_f1":f1,
        "macro_auc":macro_auc
    }

def label_smooth_ce(logits, labels, smooth=0.1):
    n_classes = logits.size(-1)
    one_hot = torch.zeros_like(logits).scatter(1, labels.unsqueeze(1),1)
    smooth_label = one_hot * (1-smooth) + smooth / n_classes
    loss = torch.sum(- smooth_label * F.log_softmax(logits,dim=-1),dim=1).mean()
    return loss

def plot_confusion_matrix(y_true,y_pred,class_names,save_path):
    cm = confusion_matrix(y_true,y_pred)
    plt.figure(figsize=(8,8))
    plt.imshow(cm,cmap="Reds")
    plt.colorbar()
    plt.xticks(range(len(class_names)),class_names,rotation=45)
    plt.yticks(range(len(class_names)),class_names)
    for i in range(len(class_names)):
        for j in range(len(class_names)):
            plt.text(j,i,cm[i,j],ha="center",va="center")
    plt.tight_layout()
    plt.savefig(save_path,dpi=150)
    plt.close()

def set_seed(seed):
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
