# evaluate.py
import numpy as np
import torch
from torch.utils.data import DataLoader
from config import cfg
from dataset import PigAcousticDataset
from model import HCF_TT
from utils import set_seed, calc_metrics, plot_confusion_matrix

def evaluate_model(model, dataset):
    loader = DataLoader(dataset,batch_size=cfg.batch_size,shuffle=False)
    model.eval()
    yt, yp, ypb = [],[],[]
    with torch.no_grad():
        for b in loader:
            w = b["waveform"].to(cfg.device)
            lm = b["logmel"].to(cfg.device)
            mf = b["mfcc"].to(cfg.device)
            lab = b["label"].cpu().numpy()
            logits = model(w,lm,mf)
            prob = torch.softmax(logits,-1).cpu().numpy()
            pred = np.argmax(prob,axis=-1)
            yt.extend(lab)
            yp.extend(pred)
            ypb.extend(prob)
    met = calc_metrics(yt, yp, np.array(ypb), cfg.num_classes)
    return met, yt, yp

def source_domain_test(test_samples, ckpt_path):
    ds = PigAcousticDataset(test_samples)
    model = HCF_TT().to(cfg.device)
    model.load_state_dict(torch.load(ckpt_path,map_location=cfg.device))
    metrics, y_true, y_pred = evaluate_model(model, ds)
    print("==== Source‑Domain Test Result ====")
    print(f"Accuracy: {metrics['acc']:.4f}")
    print(f"Macro‑Precision: {metrics['macro_precision']:.4f}")
    print(f"Macro‑Recall: {metrics['macro_recall']:.4f}")
    print(f"Macro‑F1: {metrics['macro_f1']:.4f}")
    print(f"Macro‑AUC: {metrics['macro_auc']:.4f}")
    plot_confusion_matrix(y_true,y_pred,cfg.class_names,"source_confusion.png")
    return metrics

def cross_farm_evaluate(yy_samples, yj_samples, ckpt_path):
    ds_yy = PigAcousticDataset(yy_samples)
    ds_yj = PigAcousticDataset(yj_samples)
    model = HCF_TT().to(cfg.device)
    model.load_state_dict(torch.load(ckpt_path,map_location=cfg.device))
    met_yy,_,_ = evaluate_model(model, ds_yy)
    met_yj,_,_ = evaluate_model(model, ds_yj)
    print("==== Cross‑Farm YY result ====")
    print(f"F1 {met_yy['macro_f1']:.4f} Acc {met_yy['acc']:.4f}")
    print("==== Cross‑Farm YJ result ====")
    print(f"F1 {met_yj['macro_f1']:.4f} Acc {met_yj['acc']:.4f}")
    return met_yy, met_yj

if __name__ == "__main__":
    # TODO: fill real samples
    test_samples = []
    yy_samples = []
    yj_samples = []
    ckpt_file = "fold_seed42_best.pt"
    source_domain_test(test_samples, ckpt_file)
    cross_farm_evaluate(yy_samples,yj_samples, ckpt_file)
