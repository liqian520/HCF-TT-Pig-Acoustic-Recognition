# config.py
import torch

class Config:
    # hardware
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    seed = 42

    # audio
    sample_rate = 16000
    clip_duration = 1  # 1秒片段
    hop_length = 160
    win_length = 400
    n_mels = 80
    n_mfcc = 40

    # model
    hcf_in_groups = 3
    intra_group_conv = 2
    fusion_kernel = 3
    compress_dim = 256
    tdnn_layers = 5
    tdnn_dilations = [1,2,4,8,16]
    tdnn_kernel_radius = 2
    transformer_layers =4
    attn_heads=8
    ff_dim=512
    dropout=0.1
    num_classes=5

    # train
    lr = 1e-4
    beta1=0.9
    beta2=0.999
    batch_size=32
    max_epochs=100
    early_stop_patience=10
    label_smoothing=0.1
    n_fold=4
    repeat_seeds = [42,123,256,789,1024]

    # class mapping
    class_names = ["Normal","Feeding","Squeal","Cough","Estrus"]

cfg = Config()
