# dataset.py
import os
import librosa
import numpy as np
import torch
from torch.utils.data import Dataset
import torchaudio.transforms as T
from config import cfg

def extract_three_representation(wave_np, sr):
    # waveform, log‑mel, mfcc+delta+delta2
    waveform = wave_np.astype(np.float32)

    # log mel
    mel_spec = librosa.feature.melspectrogram(y=waveform,sr=sr,n_mels=cfg.n_mels,
        win_length=cfg.win_length, hop_length=cfg.hop_length)
    log_mel = np.log10(np.clip(mel_spec, a_min=1e-8, a_max=None))

    # mfcc + delta + delta2
    mfcc = librosa.feature.mfcc(y=waveform,sr=sr,n_mfcc=cfg.n_mfcc,
        win_length=cfg.win_length, hop_length=cfg.hop_length)
    delta1 = librosa.feature.delta(mfcc)
    delta2 = librosa.feature.delta(mfcc,order=2)
    mfcc_all = np.concatenate([mfcc,delta1,delta2],axis=0)

    return waveform, log_mel.astype(np.float32), mfcc_all.astype(np.float32)


class PigAcousticDataset(Dataset):
    def __init__(self, samples):
        """
        samples: list of dict {"audio_path":str, "label":int, "group_id":int}
        group_id: pen/animal id for group‑aware split
        """
        self.samples = samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        item = self.samples[idx]
        wav, sr = librosa.load(item["audio_path"],sr=cfg.sample_rate)
        # force to 1s
        target_len = cfg.sample_rate * cfg.clip_duration
        if len(wav) > target_len:
            wav = wav[:target_len]
        else:
            wav = np.pad(wav,(0,max(0,target_len-len(wav))))

        wave, logmel, mfcc = extract_three_representation(wav, sr)
        label = int(item["label"])
        group_id = int(item["group_id"])

        return {
            "waveform": torch.from_numpy(wave),
            "logmel": torch.from_numpy(logmel),
            "mfcc": torch.from_numpy(mfcc),
            "label": torch.tensor(label,dtype=torch.long),
            "group_id": torch.tensor(group_id,dtype=torch.long)
        }

# data augment (simulate farm noise)
class AugmentTransform:
    def __call__(self, waveform):
        noise = 0.001 * torch.randn_like(waveform)
        return torch.clamp(waveform+noise, -1,1)
