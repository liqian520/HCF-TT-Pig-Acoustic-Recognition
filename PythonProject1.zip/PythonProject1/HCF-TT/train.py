# train.py
import os
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.model_selection import GroupKFold
from tqdm import tqdm

from config import cfg
from dataset import PigAcousticDataset
from model import HCF_TT
from utils import set_seed, label_smooth_ce, calc_metrics

def run_one_fold(train_set, val_set, seed):
    set_seed(seed)
    train_loader = DataLoader(train_set,batch_size=cfg.batch_size,shuffle=True,num_workers=0)
    val_loader = DataLoader(val_set,batch_size=cfg.batch_size,shuffle=False,num_workers=0)

    model = HCF_TT().to(cfg.device)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr, betas=(cfg.beta1,cfg.beta2))
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=cfg.max_epochs)

    best_f1 = 0.0
    best_epoch = 0
    patience = cfg.early_stop_patience
    stop_count =0

    for ep in range(cfg.max_epochs):
        model.train()
        train_loss = 0.0
        for batch in tqdm(train_loader,leave=False):
            wav = batch["waveform"].to(cfg.device)
            lm = batch["logmel"].to(cfg.device)
            mf = batch["mfcc"].to(cfg.device)
            lab = batch["label"].to(cfg.device)
            logits = model(wav, lm, mf)
            loss = label_smooth_ce(logits, lab, cfg.label_smoothing)
            opt.zero_grad()
            loss.backward()
            opt.step()
            train_loss += loss.item()
        scheduler.step()

        # val
        model.eval()
        y_true_val = []
        y_pred_val = []
        y_prob_val = []
        with torch.no_grad():
            for batch in val_loader:
                wav = batch["waveform"].to(cfg.device)
                lm = batch["logmel"].to(cfg.device)
                mf = batch["mfcc"].to(cfg.device)
                lab = batch["label"].cpu().numpy()
                logits = model(wav, lm, mf)
                prob = torch.softmax(logits,dim=-1).cpu().numpy()
                pred = np.argmax(prob,axis=-1)
                y_true_val.extend(lab)
                y_pred_val.extend(pred)
                y_prob_val.extend(prob)
        met = calc_metrics(y_true_val,y_pred_val,np.array(y_prob_val),cfg.num_classes)
        print(f"ep {ep:03d} val acc {met['acc']:.4f} f1 {met['macro_f1']:.4f}")

        if met["macro_f1"] > best_f1:
            best_f1 = met["macro_f1"]
            best_epoch = ep
            stop_count=0
            torch.save(model.state_dict(), f"fold_seed{seed}_best.pt")
        else:
            stop_count +=1
            if stop_count >= patience:
                break
    return best_epoch, best_f1


def group_kfold_run(all_samples):
    gkf = GroupKFold(n_splits=cfg.n_fold)
    groups = [s["group_id"] for s in all_samples]
    fold_best_epochs = []
    for seed in cfg.repeat_seeds:
        for fold_idx, (train_idx,val_idx) in enumerate(gkf.split(all_samples,groups=groups)):
            tr_samples = [all_samples[i] for i in train_idx]
            va_samples = [all_samples[i] for i in val_idx]
            tr_ds = PigAcousticDataset(tr_samples)
            va_ds = PigAcousticDataset(va_samples)
            be, bf1 = run_one_fold(tr_ds, va_ds, seed)
            fold_best_epochs.append(be)
    median_epoch = int(np.median(fold_best_epochs))
    print(f"cross‑val median best epoch: {median_epoch}")
    return median_epoch

if __name__ == "__main__":
    print("==== HCF‑TT Training start ====")
    # note: you need build your samples list by reading your dataset files
    all_samples = []
    # TODO: fill your real dataset path
    # all_samples.append({"audio_path":"xxx.wav","label":0,"group_id":1})
    median_ep = group_kfold_run(all_samples)
