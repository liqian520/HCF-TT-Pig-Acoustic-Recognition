# model.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from config import cfg

# -------------------------- Hierarchical Cross‑Domain Fusion --------------------------
class IntraGroupConv(nn.Module):
    def __init__(self, in_c, out_c, kernel_size=3):
        super().__init__()
        self.conv1 = nn.Conv1d(in_c, out_c, kernel_size,padding=kernel_size//2)
        self.bn1 = nn.BatchNorm1d(out_c)
        self.conv2 = nn.Conv1d(out_c, out_c, kernel_size,padding=kernel_size//2)
        self.bn2 = nn.BatchNorm1d(out_c)
        self.drop = nn.Dropout(cfg.dropout)

    def forward(self, x):
        x = F.relu(self.bn1(self.conv1(x)))
        x = self.drop(x)
        x = F.relu(self.bn2(self.conv2(x)))
        return x

class FusionLevel(nn.Module):
    def __init__(self, in_c, out_c, kernel=3):
        super().__init__()
        self.conv = nn.Conv1d(in_c, out_c, kernel_size=kernel, padding=kernel//2)
        self.bn = nn.BatchNorm1d(out_c)

    def forward(self, cat_x):
        return F.relu(self.bn(self.conv(cat_x)))

class ChannelRecalibrate(nn.Module):
    def __init__(self, channel):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.mlp = nn.Sequential(
            nn.Linear(channel, channel//4),
            nn.ReLU(),
            nn.Linear(channel//4, channel),
            nn.Sigmoid()
        )

    def forward(self, x):
        b,c,_ = x.shape
        s = self.pool(x).view(b,c)
        att = self.mlp(s).view(b,c,1)
        return x * att

class HCFusion(nn.Module):
    def __init__(self):
        super().__init__()
        # three branch: waveform, logmel, mfcc
        self.wave_enc = nn.Conv1d(1,64,kernel_size=5,stride=1,padding=2)
        self.wave_intra = IntraGroupConv(64, 128)

        self.logmel_intra = IntraGroupConv(80,128)
        self.mfcc_intra = IntraGroupConv(120,128)

        self.fuse_l1 = FusionLevel(128+128,128)
        self.fuse_l2 = FusionLevel(128+128,128)
        self.compress_conv = nn.Conv1d(128*3, cfg.compress_dim, kernel_size=1)
        self.recalib = ChannelRecalibrate(cfg.compress_dim)

    def forward(self, wave, logmel, mfcc):
        b = wave.shape[0]
        wave = wave.unsqueeze(1)
        xw = self.wave_enc(wave)
        xw = self.wave_intra(xw)

        xm = self.logmel_intra(logmel)
        xmf = self.mfcc_intra(mfcc)

        # level‑1 fuse wave & logmel
        f1 = self.fuse_l1(torch.cat([xw, xm],dim=1))
        # level‑2 fuse f1 with mfcc branch
        f2 = self.fuse_l2(torch.cat([f1, xmf],dim=1))

        cat_all = torch.cat([xw, f1, f2],dim=1)
        feat = self.compress_conv(cat_all)
        feat = self.recalib(feat)
        return feat

# -------------------------- TDNN local temporal --------------------------
class TDNNLayer(nn.Module):
    def __init__(self, in_dim, out_dim, dilation, kernel_radius=2):
        super().__init__()
        k = 2*kernel_radius +1
        self.conv = nn.Conv1d(in_dim, out_dim, kernel_size=k, dilation=dilation, padding=dilation*kernel_radius)
        self.bn = nn.BatchNorm1d(out_dim)
        self.drop = nn.Dropout(cfg.dropout)

    def forward(self,x):
        return self.drop(F.relu(self.bn(self.conv(x))))

class TDNNLocal(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        layers = []
        cur = in_dim
        for d in cfg.tdnn_dilations:
            layers.append(TDNNLayer(cur, cfg.compress_dim, d, cfg.tdnn_kernel_radius))
            cur = cfg.compress_dim
        self.tdnn_blocks = nn.Sequential(*layers)
        self.proj = nn.Conv1d(cur, cfg.compress_dim,1)

    def forward(self,x):
        x = self.tdnn_blocks(x)
        return self.proj(x)

# -------------------------- Transformer Global temporal --------------------------
class TransGlobal(nn.Module):
    def __init__(self, feat_dim, heads, ff_hidden, num_layers, drop):
        super().__init__()
        encoder_layer = nn.TransformerEncoderLayer(d_model=feat_dim, nhead=heads,
            dim_feedforward=ff_hidden, dropout=drop, batch_first=True)
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

    def forward(self,x):
        # x: B,C,T -> B,T,C
        x = x.transpose(1,2)
        out = self.encoder(x)
        return out.transpose(1,2)

# -------------------------- Attention Statistics Pooling --------------------------
class AttnStatPool(nn.Module):
    def __init__(self, feat_dim):
        super().__init__()
        self.attn_fc = nn.Linear(feat_dim, 1)

    def forward(self, feat):
        # feat B,C,T
        b,c,t = feat.shape
        ft = feat.transpose(1,2)
        score = self.attn_fc(ft).squeeze(-1)
        att_w = F.softmax(score, dim=-1).unsqueeze(-1) # B,T,1
        weighted = ft * att_w
        mean = weighted.sum(dim=1)
        var = ((ft - mean.unsqueeze(1))**2 * att_w).sum(dim=1)
        stat = torch.cat([mean, var],dim=-1)
        return stat

# -------------------------- Full HCF‑TT Model --------------------------
class HCF_TT(nn.Module):
    def __init__(self):
        super().__init__()
        self.hcf = HCFusion()
        self.tdnn_local = TDNNLocal(cfg.compress_dim)
        self.trans_global = TransGlobal(cfg.compress_dim, cfg.attn_heads, cfg.ff_dim, cfg.transformer_layers, cfg.dropout)
        self.pool = AttnStatPool(cfg.compress_dim)
        self.classifier = nn.Linear(cfg.compress_dim*2, cfg.num_classes)

    def forward(self, waveform, logmel, mfcc):
        f_hcf = self.hcf(waveform, logmel, mfcc)
        f_local = self.tdnn_local(f_hcf)
        f_global = self.trans_global(f_local)
        stat_vec = self.pool(f_global)
        logits = self.classifier(stat_vec)
        return logits
